-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2023 at 03:07 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pawsnpages_db`
--
CREATE DATABASE IF NOT EXISTS `pawsnpages_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `pawsnpages_db`;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `AddressID` int(11) NOT NULL,
  `LotNo_Street` varchar(400) NOT NULL,
  `Barangay` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Province` varchar(50) NOT NULL,
  `ZIPCode` varchar(20) NOT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`AddressID`, `LotNo_Street`, `Barangay`, `City`, `Province`, `ZIPCode`, `UserID`) VALUES
(1, 'B12 L14 Regency Drive Street', 'Camp Aguinaldo', 'Quezon City', 'NCR', '4114', 2),
(2, 'Unit 3018 Taft Avenue', 'Barangay 725', 'Manila', 'NCR', '1004', 3),
(6, '3124 Limay Street', '137404139', 'Quezon City', 'NCR', '1012', 11),
(12, '3509 Taft Avenue', 'Amihan', 'Quezon City', 'NCR', '1234', 14);

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `AppointmentID` int(11) NOT NULL,
  `Notes` varchar(200) DEFAULT NULL,
  `PreferredDate` date NOT NULL,
  `PreferredTime` time NOT NULL,
  `AppointmentStatus` varchar(100) DEFAULT NULL,
  `Remarks` varchar(200) DEFAULT NULL,
  `AvailedServices` varchar(1000) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Appointment_RefNo` varchar(200) NOT NULL,
  `ClinicID` int(11) DEFAULT NULL,
  `DateTimeBooked` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`AppointmentID`, `Notes`, `PreferredDate`, `PreferredTime`, `AppointmentStatus`, `Remarks`, `AvailedServices`, `UserID`, `Appointment_RefNo`, `ClinicID`, `DateTimeBooked`) VALUES
(2, 'Hello', '2023-06-15', '15:27:43', 'Confirmed', 'Done', '2', 2, '', NULL, NULL),
(3, 'N/A', '2023-06-16', '19:00:00', 'Processing', '', '1', 2, '', NULL, NULL),
(4, '', '2023-06-23', '08:00:00', 'Denied', 'Please choose a different time slot', '2', 2, '', NULL, NULL),
(6, '', '2023-06-30', '10:00:00', NULL, NULL, '5', 2, '', NULL, NULL),
(7, '', '2023-06-14', '10:30:00', NULL, NULL, '6', 2, '', NULL, NULL),
(8, '', '2023-06-18', '10:36:00', NULL, NULL, '1', 2, '', NULL, NULL),
(9, '', '2023-06-30', '18:00:00', NULL, NULL, '6', 2, '', NULL, NULL),
(10, 'my pet has a fever', '2023-06-19', '08:00:00', NULL, NULL, '8', 2, '', NULL, NULL),
(11, '', '2023-06-23', '22:10:00', 'Processing', NULL, '4', 2, '', NULL, NULL),
(12, 'N/A', '2023-06-23', '22:00:00', 'Processing', NULL, 'Parasite Control, Vaccination', 2, 'PNP23062012642', NULL, NULL),
(13, '', '2023-06-30', '12:00:00', 'Processing', NULL, 'Grooming, Vaccination', 2, 'PNP23062032073', NULL, NULL),
(14, '', '2023-06-29', '20:00:00', 'Processing', NULL, 'Vaccination', 2, 'PNP2306204950', NULL, NULL),
(15, '', '2023-06-29', '20:00:00', 'Processing', NULL, 'Dental Care', 2, 'PNP23062014043', 4, NULL),
(16, '', '2023-06-28', '12:00:00', 'Processing', NULL, 'Surgery', 2, 'PNP23062084191', 3, NULL),
(17, '', '2023-06-28', '13:00:00', 'Processing', NULL, 'Vaccination', 2, 'PNP23062096384', 5, NULL),
(18, '', '2023-06-29', '11:00:00', 'Processing', '', 'Grooming, Vaccination', 2, 'PNP23062658591', 1, NULL),
(19, 'N/A', '2023-06-29', '15:00:00', 'Denied', '', 'Grooming, Vaccination', 2, 'PNP2306261964', 1, NULL),
(20, '', '2023-06-30', '23:00:00', 'Processing', NULL, 'Grooming, Vaccination', 2, 'PNP23062648201', 1, NULL),
(21, '', '2023-06-29', '16:00:00', 'Processing', NULL, 'Grooming', 2, 'PNP23062653959', 1, NULL),
(22, '', '2023-06-30', '15:00:00', 'Processing', '', 'Grooming, Parasite Control', 2, 'PNP23062638277', 1, NULL),
(23, '', '2023-06-30', '09:00:00', 'Confirmed', '', 'Parasite Control', 2, 'PNP230627154', 1, '2023-06-27 06:32:21'),
(24, '', '2023-06-29', '21:40:00', 'Confirmed', '', 'Vaccination', 2, 'PNP23062756215', 1, '2023-06-27 06:37:23'),
(25, '', '2023-07-20', '13:00:00', 'Confirmed', '', 'Grooming, Parasite Control', 2, 'PNP23070144168', 1, '2023-07-01 01:32:39');

-- --------------------------------------------------------

--
-- Table structure for table `barangay`
--

CREATE TABLE `barangay` (
  `BarangayID` int(11) NOT NULL,
  `BarangayName` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barangay`
--

INSERT INTO `barangay` (`BarangayID`, `BarangayName`) VALUES
(1, 'Alicia'),
(2, 'Amihan'),
(3, 'Apolonio Samson'),
(4, 'Aurora'),
(5, 'Baesa'),
(6, 'Bagbag'),
(7, 'Bagong Lipunan Ng Crame'),
(8, 'Bagong Pag-asa'),
(9, 'Bagong Silangan'),
(10, 'Bagumbayan'),
(11, 'Bagumbuhay'),
(12, 'Bahay Toro'),
(13, 'Balingasa'),
(14, 'Balong Bato'),
(15, 'Batasan Hills'),
(16, 'Bayanihan'),
(17, 'Blue Ridge A'),
(18, 'Blue Ridge B'),
(19, 'Botocan'),
(20, 'Bungad'),
(21, 'Camp Aguinaldo'),
(22, 'Capri'),
(23, 'Central'),
(24, 'Claro'),
(25, 'Commonwealth'),
(26, 'Culiat'),
(27, 'Damar'),
(28, 'Damayan'),
(29, 'Damayang Lagi'),
(30, 'Del Monte'),
(31, 'Dioquino Zobel'),
(32, 'Doña Imelda'),
(33, 'Doña Josefa'),
(34, 'Don Manuel'),
(35, 'Duyan-Duyan'),
(36, 'East Kamias'),
(37, 'E. Rodriguez'),
(38, 'Escopa I'),
(39, 'Escopa II'),
(40, 'Escopa III'),
(41, 'Escopa IV'),
(42, 'Fairview'),
(43, 'Greater Lagro'),
(44, 'Gulod'),
(45, 'Holy Spirit'),
(46, 'Horseshoe'),
(47, 'Immaculate Concepcion'),
(48, 'Kaligayahan'),
(49, 'Kalusugan'),
(50, 'Kamuning'),
(51, 'Katipunan'),
(52, 'Kaunlaran'),
(53, 'Kristong Hari'),
(54, 'Krus Na Ligas'),
(55, 'Laging Handa'),
(56, 'Libis'),
(57, 'Lourdes'),
(58, 'Loyola Heights'),
(59, 'Maharlika'),
(60, 'Malaya'),
(61, 'Mangga'),
(62, 'Manresa'),
(63, 'Mariana'),
(64, 'Mariblo'),
(65, 'Marilag'),
(66, 'Masagana'),
(67, 'Masambong'),
(68, 'Matandang Balara'),
(69, 'Milagrosa'),
(70, 'Nagkaisang Nayon'),
(71, 'Nayong Kanluran'),
(72, 'New Era (Constitution Hills)'),
(73, 'North Fairview'),
(74, 'Novaliches Proper'),
(75, 'N.S. Amoranto (Gintong Silahis)'),
(76, 'Obrero'),
(77, 'Old Capitol Site'),
(78, 'Paang Bundok'),
(79, 'Pag-ibig Sa Nayon'),
(80, 'Paligsahan'),
(81, 'Paltok'),
(82, 'Pansol'),
(83, 'Paraiso'),
(84, 'Pasong Putik Proper (Pasong Putik)'),
(85, 'Pasong Tamo'),
(86, 'Payatas'),
(87, 'Phil-Am'),
(88, 'Pinagkaisahan'),
(89, 'Pinyahan'),
(90, 'Project 6'),
(91, 'Quirino 2-A'),
(92, 'Quirino 2-B'),
(93, 'Quirino 2-C'),
(94, 'Quirino 3-A'),
(95, 'Ramon Magsaysay'),
(96, 'Roxas'),
(97, 'Sacred Heart'),
(98, 'Saint Ignatius'),
(99, 'Saint Peter'),
(100, 'Salvacion'),
(101, 'San Agustin'),
(102, 'San Antonio'),
(103, 'San Bartolome'),
(104, 'Sangandaan'),
(105, 'San Isidro'),
(106, 'San Isidro Labrador'),
(107, 'San Jose'),
(108, 'San Martin De Porres'),
(109, 'San Roque'),
(110, 'Santa Cruz'),
(111, 'Santa Lucia'),
(112, 'Santa Monica'),
(113, 'Santa Teresita'),
(114, 'Santo Cristo'),
(115, 'Santo Domingo (Matalahib)'),
(116, 'Santol'),
(117, 'Santo Niño'),
(118, 'San Vicente'),
(119, 'Sauyo'),
(120, 'Sienna'),
(121, 'Sikatuna Village'),
(122, 'Silangan'),
(123, 'Socorro'),
(124, 'South Triangle'),
(125, 'Tagumpay'),
(126, 'Talayan'),
(127, 'Talipapa'),
(128, 'Tandang Sora'),
(129, 'Tatalon'),
(130, 'Teachers Village East'),
(131, 'Teachers Village West'),
(132, 'Ugong Norte'),
(133, 'Unang Sigaw'),
(134, 'U.P. Campus'),
(135, 'U.P. Village'),
(136, 'Valencia'),
(137, 'Vasra'),
(138, 'Veterans Village'),
(139, 'Villa Maria Clara'),
(140, 'West Kamias'),
(141, 'West Triangle'),
(142, 'White Plains');

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--

CREATE TABLE `clinics` (
  `ClinicID` int(11) NOT NULL,
  `ClinicName` varchar(100) NOT NULL,
  `ClinicImage` varchar(100) NOT NULL,
  `BusinessPermit` varchar(100) NOT NULL,
  `BusinessNameReg` varchar(100) NOT NULL,
  `CertificateOfReg` varchar(100) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `SubscriptionNo` varchar(200) DEFAULT NULL,
  `SubscriptionType` varchar(200) NOT NULL,
  `DateOfSubscription` date DEFAULT NULL,
  `ExpiryDateOfSub` date DEFAULT NULL,
  `SubscriptionStatus` varchar(200) DEFAULT NULL,
  `OpeningTime` time NOT NULL,
  `ClosingTime` time NOT NULL,
  `OperatingDays` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`ClinicID`, `ClinicName`, `ClinicImage`, `BusinessPermit`, `BusinessNameReg`, `CertificateOfReg`, `UserID`, `SubscriptionNo`, `SubscriptionType`, `DateOfSubscription`, `ExpiryDateOfSub`, `SubscriptionStatus`, `OpeningTime`, `ClosingTime`, `OperatingDays`) VALUES
(1, 'Metropolitan Clinic', 'boc.png', '', '', '', 2, NULL, '', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(2, 'Hello Clinic', '', '', '', '', 3, NULL, '', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(3, 'Bagong Clinic', '', '', '', '', 3, NULL, '', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(4, 'Asul na Clinic', '', '', '', '', 5, NULL, '', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(5, 'Ospital ng Maynila', '', 'boba u4 silent tactile.png', 'xv sti kit catalog.pdf', '111021944_1000752330359701_9174086897199949797_n.png', 11, NULL, 'monthly', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(6, 'Zoo Clinic', '', 'okpgL0.png', '736227.png', '1119150.jpg', 12, NULL, 'annually', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(7, 'Ayos na Clinic', '', 'Bootstrap-Checklist.jpg', 'boba u4 silent tactile.png', 'brutal60 wkl.png', 13, NULL, 'annually', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday'),
(8, 'Doc Ferds', '', '2014-subaru-forester-ts-3.jpg', 'IMG_5187-1024x683.jpg', '93013842_3131008436920142_5528901233953210368_n.jpg', 14, NULL, 'annually', NULL, NULL, 'Active', '08:00:00', '20:00:00', 'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_billing`
--

CREATE TABLE `clinic_billing` (
  `BillingID` int(11) NOT NULL,
  `BillingImage` varchar(400) DEFAULT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FeedbackID` int(11) NOT NULL,
  `Rating` float NOT NULL,
  `OverallFeedback` varchar(5000) DEFAULT NULL,
  `DateTimeRated` datetime DEFAULT NULL,
  `ClinicID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FeedbackID`, `Rating`, `OverallFeedback`, `DateTimeRated`, `ClinicID`, `UserID`) VALUES
(1, 5, 'The veterinary clinic is very clean and the doctors are all skillful. On top of that, their products are actually really, really nice.', '2023-06-28 07:20:34', 1, 2),
(2, 5, NULL, '2023-06-28 07:21:21', 1, 2),
(3, 5, 'Hello', '2023-06-28 11:56:13', 1, 2),
(4, 3, NULL, '2023-06-28 11:56:27', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `OrderDetailsID` int(11) NOT NULL,
  `SupplyID` int(11) DEFAULT NULL,
  `UserID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` float NOT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`OrderDetailsID`, `SupplyID`, `UserID`, `Quantity`, `Price`, `ClinicID`) VALUES
(31, 22, 2, 14, 21000, 3),
(51, 17, 7, 1, 2150, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `Order_RefNo` varchar(250) DEFAULT NULL,
  `OrderedProducts` varchar(5000) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TotalPrice` float NOT NULL,
  `DateTimeCheckedOut` datetime NOT NULL,
  `ShippingTo` varchar(5000) NOT NULL,
  `ProofOfPayment` varchar(500) NOT NULL,
  `Proof_RefNo` varchar(200) NOT NULL,
  `OrderStatus` varchar(500) DEFAULT NULL,
  `OrderRemarks` varchar(1000) DEFAULT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `Order_RefNo`, `OrderedProducts`, `UserID`, `TotalPrice`, `DateTimeCheckedOut`, `ShippingTo`, `ProofOfPayment`, `Proof_RefNo`, `OrderStatus`, `OrderRemarks`, `ClinicID`) VALUES
(1, 'ODRN23062759917', '(7x) Leash, (2x) Testing 1, (14x) Testing 2, (7x) Testing 3, ', 2, 56361, '2023-06-27 05:56:02', 'B12 L14 Regency Drive Street, Sampaloc II, Dasmarinas, Cavite, 4114', 'Coquilla-PROJ3(Part 1).JPG', 'GCASH1234', 'Pending', NULL, 1),
(2, 'ODRN23062792542', '(14x) Testing 4, ', 2, 21000, '2023-06-27 11:12:15', 'B13 L15 Sultan Sanctum Street, White Plains, Quezon City, NCR, 1234', 'Coquilla-PROJ3 (Part 2).JPG', 'GCASH98475', 'Completed', NULL, 3),
(3, 'ODRN23062871917', '(7x) Leash, (14x) Testing 2, (7x) Testing 3, ', 2, 53361, '2023-06-28 12:14:23', '4489 Limay Avenue, NCR, Quezon City, Botocan, 5565', 'IMG_2803.JPG', 'GCASH9807', 'Pending', NULL, 1),
(4, 'ODRN23062857148', '(7x) Leash, (14x) Testing 2, ', 2, 31500, '2023-06-28 12:16:05', 'B13 L15 Sultan Sanctum Street, White Plains, Quezon City, NCR, 1234', 'IMG_2804.JPG', 'GCASH98475', 'Pending', NULL, 1),
(5, 'ODRN23062889335', '(5x) Leash, ', 2, 1000, '2023-06-28 12:18:18', '7899 Roxas Crest, NCR, Quezon City, Blue Ridge A, 6755', 'Coquilla-PROJ3.JPG', 'GCASHFYEFGIE', 'Pending', NULL, 1),
(6, 'ODRN23062869', '(1x) Leash, (3x) Testing 2, (15x) Test test, ', 2, 60500, '2023-06-28 05:53:41', 'B12 L14 Regency Drive Street, Sampaloc II, Dasmarinas, Cavite, 4114', 'IMG_2804.JPG', 'GCASH1234', 'Pending', NULL, 1),
(7, 'ODRN23062872595', '(3x) Leash, ', 2, 600, '2023-06-28 06:04:32', '7899 Roxas Crest, NCR, Quezon City, Blue Ridge A, 6755', 'Coquilla-PROJ3 (Part 2).JPG', 'GCASHFYEFGIE', 'Pending', NULL, 1),
(8, 'ODRN23062878528', '(6x) Testing 2, ', 2, 12900, '2023-06-28 06:08:27', '4489 Limay Avenue, NCR, Quezon City, Botocan, 5565', 'Coquilla-PROJ3(Part 1).JPG', 'GCASH1234', 'Pending', NULL, 1),
(9, 'ODRN23062862683', '(2x) Leash, ', 2, 400, '2023-06-28 06:12:27', '4489 Limay Avenue, NCR, Quezon City, Botocan, 5565', 'Coquilla-PROJ3(Part 1).JPG', 'GCASH98475', 'Pending', NULL, 1),
(10, 'ODRN23062850545', '(2x) Leash, ', 2, 400, '2023-06-28 06:13:13', '4489 Limay Avenue, NCR, Quezon City, Botocan, 5565', 'Coquilla-PROJ3(Part 1).JPG', 'GCASH98475', 'Pending', NULL, 1),
(11, 'ODRN23062899312', '(20x) Test test, ', 2, 71800, '2023-06-28 06:15:04', 'B12 L14 Regency Drive Street, Sampaloc II, Dasmarinas, Cavite, 4114', 'Coquilla-PROJ3(Part 1).JPG', 'GCASHFYEFGIE', 'Pending', NULL, 1),
(12, 'ODRN23062878370', '(2x) Leash, (5x) Testing 2, (10x) Testing 3, ', 2, 42380, '2023-06-28 06:19:51', '4489 Limay Avenue, NCR, Quezon City, Botocan, 5565', 'Coquilla-PROJ3(Part 1).JPG', 'GCASHFYEFGIE', 'Pending', NULL, 1),
(13, 'ODRN23062890681', '(3x) Leash, ', 2, 600, '2023-06-28 06:21:58', '4489 Limay Avenue, NCR, Quezon City, Botocan, 5565', 'Coquilla-PROJ3(Part 1).JPG', 'GCASH9807', 'Completed', NULL, 1),
(14, 'ODRN23070128065', '(2x) Testing 2, ', 11, 4300, '2023-07-01 12:56:20', '3124 Limay Street, 137404139, Quezon City, NCR, 1012', 'boba u4 silent tactile.png', 'GCASH98475', 'Pending', NULL, 1),
(15, 'ODRN2307012995', '(1x) Testing 3, (5x) Leash, ', 2, 4123, '2023-07-01 01:30:04', 'B12 L14 Regency Drive Street, Camp Aguinaldo, Quezon City, NCR, 4114', 'Bootstrap-Checklist.jpg', 'GCASH1234', 'Pending', NULL, 1),
(16, 'ODRN23070316332', '(7x) Testing 2, ', 2, 15050, '2023-07-03 06:00:10', 'B12 L14 Regency Drive Street, Camp Aguinaldo, Quezon City, NCR, 4114', 'xv sti kit catalog.pdf', 'GCASH1234', 'Pending', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `petassessment`
--

CREATE TABLE `petassessment` (
  `AssessmentID` int(11) NOT NULL,
  `Remarks` varchar(150) NOT NULL,
  `DateAssessed` datetime NOT NULL,
  `AssessedBy` varchar(300) DEFAULT NULL,
  `Prescription` varchar(200) DEFAULT NULL,
  `PetID` int(11) DEFAULT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petassessment`
--

INSERT INTO `petassessment` (`AssessmentID`, `Remarks`, `DateAssessed`, `AssessedBy`, `Prescription`, `PetID`, `ClinicID`) VALUES
(1, 'healthy', '2023-06-14 17:50:19', 'hehehe', NULL, 11, NULL),
(2, 'ertertertdfgdfg', '2023-06-14 17:54:13', 'sdfgsdg', 'retro PC.png', 4, 2),
(3, 'sample', '2023-06-17 10:29:43', 'bian bian', NULL, 16, 5);

-- --------------------------------------------------------

--
-- Table structure for table `petbooklet`
--

CREATE TABLE `petbooklet` (
  `BookletID` int(11) NOT NULL,
  `Payment_Proof` varchar(500) NOT NULL,
  `RefNo_Input` varchar(200) NOT NULL,
  `NoOfPets` int(11) NOT NULL,
  `AmountToPay` varchar(200) DEFAULT NULL,
  `PaymentStatus` varchar(200) NOT NULL,
  `Remarks` varchar(500) NOT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petbooklet`
--

INSERT INTO `petbooklet` (`BookletID`, `Payment_Proof`, `RefNo_Input`, `NoOfPets`, `AmountToPay`, `PaymentStatus`, `Remarks`, `UserID`) VALUES
(1, 'Bootstrap-Checklist.jpg', 'GCASH1234', 0, '₱49.00', 'Pending', '', 2),
(2, 'Bootstrap-Checklist.jpg', 'GCASH1234', 2, '₱98.00', 'Pending', '', 7),
(3, 'buwaya.jpg', 'GCASH1234', 1, '₱49.00', 'Approved', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `PetID` int(11) NOT NULL,
  `PetImage` varchar(100) NOT NULL,
  `PetName` varchar(30) NOT NULL,
  `Species` varchar(20) NOT NULL,
  `Breed` varchar(20) NOT NULL,
  `BirthDate` date NOT NULL,
  `Color` varchar(15) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `PetUniqueID` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`PetID`, `PetImage`, `PetName`, `Species`, `Breed`, `BirthDate`, `Color`, `UserID`, `PetUniqueID`) VALUES
(1, '', 'Fluffy', 'Dog', 'Pomeranian', '2023-06-21', 'Cute Brown', 3, ''),
(4, 'boc.png', 'Zazzy', 'Dog', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(5, 'brutal60 wkl.png', 'Blake', 'Doggi', 'Pomeranianssss', '2019-01-01', 'Green', 2, ''),
(6, 'boba u4 silent tactile.png', 'Fluffy', 'Doggi', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(7, '', 'Bronnie', 'Doggi', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(8, '', 'Muji', 'Dog', 'Chow-chow', '0000-00-00', 'Beige', 3, ''),
(10, '', 'Lexy', 'Doggi', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(11, '', 'Gilbvs', 'Doggi', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(12, '', 'Gilbs', 'IDK', 'Hehe', '0000-00-00', 'Bornw', 3, ''),
(15, '', 'Bian', 'Doggi', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(16, '111021944_1000752330359701_9174086897199949797_n.png', 'Janicabicabs', 'Doggi', 'Pomeranian', '2019-01-01', 'Green', 2, ''),
(30, 'buwaya.jpg', 'Janicabs', 'Canine', 'Dog', '2019-01-01', 'Black', 2, 'PNPYXA41034'),
(31, 'buwaya.jpg', 'Gilbs', 'Crocodile', 'IDK', '2019-01-01', 'Black', 2, 'PNPTAE68163');

-- --------------------------------------------------------

--
-- Table structure for table `petsupplies`
--

CREATE TABLE `petsupplies` (
  `SupplyID` int(11) NOT NULL,
  `SupplyImage` longblob NOT NULL,
  `SupplyName` varchar(50) NOT NULL,
  `SupplyDescription` varchar(1000) NOT NULL,
  `SupplyPrice` float NOT NULL,
  `Stocks` int(11) NOT NULL,
  `NeedPrescription` varchar(11) NOT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petsupplies`
--

INSERT INTO `petsupplies` (`SupplyID`, `SupplyImage`, `SupplyName`, `SupplyDescription`, `SupplyPrice`, `Stocks`, `NeedPrescription`, `ClinicID`) VALUES
(16, 0x626f632e706e67, 'leashyleash', 'desc', 500, 453, 'No', 1),
(17, 0x3733363232372e706e67, 'Testing 2', 'Test', 2150, 8, 'Test', 1),
(19, 0x6f6b70674c302e706e67, 'Testing 3', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 3123, 14, 'No', 1),
(22, 0x426f6f7473747261702d436865636b6c6973742e6a7067, 'Testing 4', 'Testing again', 1500, 124, 'Yes', 3),
(23, 0x494d475f323830332e4a5047, 'Test test', 'testing testing lorem ipsum dolor sit amet', 3590, 490, 'No', 1),
(24, 0x626f632e706e67, 'Hello', 'asdasd', 35905, 44, 'No', 1);

-- --------------------------------------------------------

--
-- Table structure for table `petvaccine`
--

CREATE TABLE `petvaccine` (
  `VaccineID` int(11) NOT NULL,
  `VaccineName` varchar(25) NOT NULL,
  `Brand` varchar(25) NOT NULL,
  `Description` varchar(150) NOT NULL,
  `Dosage` varchar(15) NOT NULL,
  `LotNo` varchar(15) NOT NULL,
  `DateVaccinated` date NOT NULL,
  `ExpirationDate` date NOT NULL,
  `Vaccinator` varchar(50) NOT NULL,
  `PetID` int(11) DEFAULT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petvaccine`
--

INSERT INTO `petvaccine` (`VaccineID`, `VaccineName`, `Brand`, `Description`, `Dosage`, `LotNo`, `DateVaccinated`, `ExpirationDate`, `Vaccinator`, `PetID`, `ClinicID`) VALUES
(1, 'sample', 'sample', 'asldkfjlsdkjfoiqwj', '199g', '102938shjdflk', '2023-06-15', '2023-06-29', 'hello', 11, NULL),
(2, 'eesdfwert', 'ertert', 'dfgdfgdf', 'dfg', 'ertter', '2023-06-08', '2023-06-30', 'esrger', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin DEFAULT NULL,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin DEFAULT NULL,
  `data_sql` longtext COLLATE utf8_bin DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `ServiceID` int(11) NOT NULL,
  `ServiceName` varchar(50) NOT NULL,
  `ServiceDescription` varchar(150) NOT NULL,
  `ServicePrice` float NOT NULL,
  `ClinicID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`ServiceID`, `ServiceName`, `ServiceDescription`, `ServicePrice`, `ClinicID`) VALUES
(1, 'Grooming', 'Improves pet\'s hygiene and well-being', 350, 1),
(2, 'Vaccination', 'Gives immunity to pets', 3000, 2),
(3, 'Surgery', 'Cures pets from within', 25000, 3),
(4, 'Dental Care', 'Takes care of pet\'s dental care', 2500, 4),
(5, 'Parasite Control', 'To control parasite', 4500, 1),
(6, 'Vaccination', 'Vaccine', 1300, 1),
(8, 'Vaccination', 'Vaccine', 3200, 5),
(11, 'New', 'Try lang', 4500, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `MiddleName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `ContactNo` varchar(20) NOT NULL,
  `Birth_Date` date DEFAULT NULL,
  `UserType` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `DateTimeModified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FirstName`, `MiddleName`, `LastName`, `ContactNo`, `Birth_Date`, `UserType`, `Username`, `Email`, `Password`, `DateTimeModified`) VALUES
(2, 'John Gilbert', 'Marababol', 'Coquilla', '0912', NULL, 'Clinic Administrator', 'gilbertcoquilla', 'jhnglbrt1922@gmail.com', 'imgilbs', NULL),
(3, 'Czarina Bianca', 'Pagdonsolan', 'Ongkingco', '09151879481', NULL, 'Administrator', 'czarinabianca', 'czarinabianca.ongkingco@benilde.edu.ph', 'biancaokc6', NULL),
(5, 'Joshua', 'Lim', 'Coki', '0912', NULL, 'Pet Owner', 'joshcoki', 'joshcoki@gmail.com', 'joshcoki15', NULL),
(7, 'Bryan', 'Coki', 'Phil', '0934', NULL, 'Pet Owner', 'brycoki', 'brycoki@gmail.com', 'brycoki21', NULL),
(8, 'jeg', 'mara', 'babol', '0123', NULL, 'Clinic Administrator', 'hehe', 'hehe@gmail.com', 'hehehe', NULL),
(9, 'Jegz', 'Marab', 'Coq', '0123', NULL, '', 'jegz', 'jegz@gmail.com', 'jegz', NULL),
(10, 'Bian', 'Ca', 'Ong', '345', NULL, 'Clinic Administrator', 'bian', 'bian@gmail.com', 'bian', NULL),
(11, 'Sam', 'Pol', 'Name', '3124', NULL, 'Clinic Administrator', 'sampol', 'sampol@gmail.com', 'sampol', NULL),
(12, 'biang', 'kita', 'ong', '0915', NULL, 'Clinic Administrator', 'biangkita', 'biangkita@gmail.com', 'biangkita', NULL),
(13, 'kita', 'biang', 'ong', '345', NULL, 'Clinic Administrator', 'kitabiang', 'kitabiang@yahoo.com', 'kitabiang', NULL),
(14, 'Gibo', 'Ong', 'Bagoong', '567', NULL, 'Clinic Administrator', 'gibooong', 'giboong@gmail.com', 'giboong', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`AddressID`),
  ADD KEY `fk_address_users` (`UserID`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`AppointmentID`),
  ADD KEY `fk_appointments_service` (`AvailedServices`(768)),
  ADD KEY `fk_appointments_user` (`UserID`),
  ADD KEY `fk_appointments_clinic` (`ClinicID`);

--
-- Indexes for table `barangay`
--
ALTER TABLE `barangay`
  ADD PRIMARY KEY (`BarangayID`);

--
-- Indexes for table `clinics`
--
ALTER TABLE `clinics`
  ADD PRIMARY KEY (`ClinicID`),
  ADD KEY `fk_clinics_user` (`UserID`);

--
-- Indexes for table `clinic_billing`
--
ALTER TABLE `clinic_billing`
  ADD PRIMARY KEY (`BillingID`),
  ADD KEY `fk_billing_clinic` (`ClinicID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FeedbackID`),
  ADD KEY `fk_feedback_clinic` (`ClinicID`),
  ADD KEY `fk_feedback_user` (`UserID`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`OrderDetailsID`),
  ADD KEY `fk_details_supply` (`SupplyID`),
  ADD KEY `fk_details_user` (`UserID`),
  ADD KEY `fk_details_clinics` (`ClinicID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `fk_orders_user` (`UserID`),
  ADD KEY `fk_orders_clinics` (`ClinicID`);

--
-- Indexes for table `petassessment`
--
ALTER TABLE `petassessment`
  ADD PRIMARY KEY (`AssessmentID`),
  ADD KEY `fk_assessment_pet` (`PetID`),
  ADD KEY `fk_assessment_clinic` (`ClinicID`);

--
-- Indexes for table `petbooklet`
--
ALTER TABLE `petbooklet`
  ADD PRIMARY KEY (`BookletID`),
  ADD KEY `fk_booklet_users` (`UserID`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`PetID`),
  ADD KEY `fk_pets_user` (`UserID`);

--
-- Indexes for table `petsupplies`
--
ALTER TABLE `petsupplies`
  ADD PRIMARY KEY (`SupplyID`),
  ADD KEY `fk_supplies_clinic` (`ClinicID`);

--
-- Indexes for table `petvaccine`
--
ALTER TABLE `petvaccine`
  ADD PRIMARY KEY (`VaccineID`),
  ADD KEY `fk_vaccine_pet` (`PetID`),
  ADD KEY `fk_vaccine_clinic` (`ClinicID`);

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`ServiceID`),
  ADD KEY `fk_services_clinic` (`ClinicID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `AddressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `AppointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `barangay`
--
ALTER TABLE `barangay`
  MODIFY `BarangayID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `clinics`
--
ALTER TABLE `clinics`
  MODIFY `ClinicID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `clinic_billing`
--
ALTER TABLE `clinic_billing`
  MODIFY `BillingID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FeedbackID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `OrderDetailsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `petassessment`
--
ALTER TABLE `petassessment`
  MODIFY `AssessmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `petbooklet`
--
ALTER TABLE `petbooklet`
  MODIFY `BookletID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `PetID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `petsupplies`
--
ALTER TABLE `petsupplies`
  MODIFY `SupplyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `petvaccine`
--
ALTER TABLE `petvaccine`
  MODIFY `VaccineID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `ServiceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `fk_address_users` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `fk_appointments_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`),
  ADD CONSTRAINT `fk_appointments_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `clinics`
--
ALTER TABLE `clinics`
  ADD CONSTRAINT `fk_clinics_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `clinic_billing`
--
ALTER TABLE `clinic_billing`
  ADD CONSTRAINT `fk_billing_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_feedback_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`),
  ADD CONSTRAINT `fk_feedback_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `fk_details_clinics` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`),
  ADD CONSTRAINT `fk_details_supply` FOREIGN KEY (`SupplyID`) REFERENCES `petsupplies` (`SupplyID`),
  ADD CONSTRAINT `fk_details_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_clinics` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`),
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `petassessment`
--
ALTER TABLE `petassessment`
  ADD CONSTRAINT `fk_assessment_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`),
  ADD CONSTRAINT `fk_assessment_pet` FOREIGN KEY (`PetID`) REFERENCES `pets` (`PetID`);

--
-- Constraints for table `petbooklet`
--
ALTER TABLE `petbooklet`
  ADD CONSTRAINT `fk_booklet_users` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `fk_pets_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `petsupplies`
--
ALTER TABLE `petsupplies`
  ADD CONSTRAINT `fk_supplies_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`);

--
-- Constraints for table `petvaccine`
--
ALTER TABLE `petvaccine`
  ADD CONSTRAINT `fk_vaccine_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`),
  ADD CONSTRAINT `fk_vaccine_pet` FOREIGN KEY (`PetID`) REFERENCES `pets` (`PetID`);

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `fk_services_clinic` FOREIGN KEY (`ClinicID`) REFERENCES `clinics` (`ClinicID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
